package ssvv.example;

import domain.Student;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import repository.StudentXMLRepo;
import service.Service;
import validation.StudentValidator;
import validation.ValidationException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import static org.junit.jupiter.api.Assertions.*;

public class TestAddStudent {
    private StudentXMLRepo studentFileRepository;
    private StudentValidator studentValidator;
    private Service service;

    @BeforeAll
    static void createXML() {
        File xml = new File("fisiere/studentiTest.xml");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(xml))) {
            writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n" +
                    "<inbox>\n" +
                    "\n" +
                    "</inbox>");
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @BeforeEach
    public void setup() {
        this.studentFileRepository = new StudentXMLRepo("fisiere/studentiTest.xml");
        this.studentValidator = new StudentValidator();
        this.service = new Service(this.studentFileRepository, this.studentValidator, null, null, null, null);
    }

    @AfterAll
    static void removeXML() {
        new File("fisiere/studentiTest.xml").delete();
    }

    @Test
    public void testAddDuplicateStudent() {
        Student student1 = new Student("1", "Doru", 931, "doru@mail.com");

        Student addedStudent1 = this.service.addStudent(student1);
        assertNull(addedStudent1);

        Student addedStudent2 = this.service.addStudent(student1);
        assertEquals(student1.getID(), addedStudent2.getID());

        this.service.deleteStudent("1");
    }

    @Test
    public void testAddUniqueStudents() {
        Student student1 = new Student("1", "Doru", 931, "doru@mail.com");
        Student student2 = new Student("2", "Doru", 931, "doru@mail.com");

        Student addedStudent1 = this.service.addStudent(student1);
        assertNull(addedStudent1);

        Student addedStudent2 = this.service.addStudent(student2);
        assertNull(addedStudent2);

        var students = this.service.getAllStudenti().iterator();
        assertEquals(students.next().getID(), student1.getID());
        assertEquals(students.next().getID(), student2.getID());

        this.service.deleteStudent("1");
        this.service.deleteStudent("2");
    }

    @Test
    public void testAddStudentWithValidName() {
        Student student = new Student("1", "Doru", 931, "doru@mail.com");
        this.service.addStudent(student);
        var students = this.service.getAllStudenti().iterator();
        assertEquals(students.next().getID(), student.getID());
        this.service.deleteStudent("1");
    }

    @Test
    public void testAddStudentWithEmptyName() {
        Student student = new Student("2", "", 931, "doru@mail.com");
        assertThrows(ValidationException.class, () -> this.service.addStudent(student));
    }

    @Test
    public void testAddStudentWithNullName() {
        Student student = new Student("3", null, 931, "doru@mail.com");
        assertThrows(ValidationException.class, () -> this.service.addStudent(student));
    }

    @Test
    public void testAddStudentWithValidGroup() {
        Student student = new Student("1", "Doru", 931, "doru@mail.com");
        this.service.addStudent(student);
        var students = this.service.getAllStudenti().iterator();
        assertEquals(students.next().getID(), student.getID());
        this.service.deleteStudent("1");
    }

    @Test
    public void testAddStudentWithInvalidGroup() {
        Student student = new Student("2", "Doru", -6, "doru@mail.com");
        assertThrows(ValidationException.class, () -> this.service.addStudent(student));
    }

    @Test
    public void testAddStudentWithValidEmail() {
        Student student = new Student("1", "Doru", 931, "doru@mail.com");
        this.service.addStudent(student);
        var students = this.service.getAllStudenti().iterator();
        assertEquals(students.next().getID(), student.getID());
        this.service.deleteStudent("1");
    }

    @Test
    public void testAddStudentWithEmptyEmail() {
        Student student = new Student("2", "Doru", 931, "");
        assertThrows(ValidationException.class, () -> this.service.addStudent(student));
    }

    @Test
    public void testAddStudentWithNullEmail() {
        Student student = new Student("3", "Doru", 931, null);
        assertThrows(ValidationException.class, () -> this.service.addStudent(student));
    }

    @Test
    public void testAddStudentWithValidId() {
        Student student = new Student("2345", "Doru", 931, "doru@mail.com");
        this.service.addStudent(student);
        var students = this.service.getAllStudenti().iterator();
        assertEquals(students.next().getID(), student.getID());
        this.service.deleteStudent("2345");
    }

    @Test
    public void testAddStudentWithEmptyId() {
        Student student = new Student("", "Doru", 931, "doru@mail.com");
        assertThrows(ValidationException.class, () -> this.service.addStudent(student));
    }

    @Test
    public void testAddStudentWithNullId() {
        assertThrows(ValidationException.class, () -> {
            Student student = new Student(null, "Doru", 931, "doru@mail.com");
        });
    }

    /**
     * Boundary Value Analysis (BVA) Test Case
     */
    @Test
    public void testAddStudentAtLowerGroupBoundary() {
        Student student = new Student("1", "Doru", 0, "doru@mail.com");
        this.service.addStudent(student);
        var students = this.service.getAllStudenti().iterator();
        assertEquals(students.next().getID(), student.getID());
        this.service.deleteStudent("1");
    }
}
