package org.example.pages;

import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

import java.util.List;
import java.util.stream.Collectors;

@DefaultUrl("https://computer-database.gatling.io/computers")
public class ComputerDatabasePage extends PageObject {

    // --- Search functionality ---
    @FindBy(id = "searchbox")
    private WebElementFacade searchBox;

    @FindBy(id = "searchsubmit")
    private WebElementFacade searchButton;

    @FindBy(css = ".computers.zebra-striped tbody tr td a")
    private List<WebElementFacade> searchResults;

    // --- Add computer functionality ---
    @FindBy(id = "add")
    private WebElementFacade addNewComputerButton;

    @FindBy(id = "name")
    private WebElementFacade nameField;

    @FindBy(id = "introduced")
    private WebElementFacade introducedDateField;

    @FindBy(id = "discontinued")
    private WebElementFacade discontinuedDateField;

    @FindBy(id = "company")
    private WebElementFacade companyDropdown;

    @FindBy(css = "input[type='submit']")
    private WebElementFacade createComputerButton;

    @FindBy(css = "div.alert-message.warning")
    private WebElementFacade successMessage;

    @FindBy(css = "span.help-inline")
    private List<WebElementFacade> validationErrors;

    // --- Methods for search ---
    public void searchFor(String keyword) {
        searchBox.type(keyword);
        searchButton.click();
    }

    public List<String> getSearchResults() {
        List<WebElementFacade> refreshedResults = findAll(By.cssSelector(".computers.zebra-striped tbody tr td a"));
        return refreshedResults.stream()
                .map(WebElementFacade::getText)
                .collect(Collectors.toList());
    }

    public boolean isNoResultsMessageVisible() {
        List<WebElementFacade> noResultsElements = findAll(By.cssSelector(".well em"));
        if (noResultsElements.isEmpty()) {
            return false;
        }
        WebElementFacade noResults = noResultsElements.get(0);
        return noResults.isVisible() && noResults.containsText("Nothing to display");
    }

    public String getNoResultsMessage() {
        WebElementFacade noResults = find(By.cssSelector(".well em"));
        noResults.waitUntilVisible();
        return noResults.getText().trim();
    }

    // --- Methods for adding a computer ---
    public void goToAddComputerForm() {
        addNewComputerButton.click();
    }

    public void fillComputerForm(String name, String introduced, String discontinued, String company) {
        nameField.type(name);
        introducedDateField.type(introduced);
        discontinuedDateField.type(discontinued);
        companyDropdown.selectByVisibleText(company);
    }

    public void submitComputerForm() {
        createComputerButton.click();
    }

    public String getSuccessMessage() {
        successMessage.waitUntilVisible();
        return successMessage.getText().trim();
    }

    public boolean hasValidationErrors() {
        return !validationErrors.isEmpty();
    }
}
