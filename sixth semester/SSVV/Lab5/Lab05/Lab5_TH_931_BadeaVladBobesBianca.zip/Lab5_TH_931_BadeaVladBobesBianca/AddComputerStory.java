package org.example.features.search;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.junit.annotations.UseTestDataFrom;
import net.thucydides.junit.annotations.Qualifier;
import org.example.steps.serenity.ComputerSteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/AddComputer.csv")
public class AddComputerStory {

    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public ComputerSteps user;

    private String name;
    private String introduced;
    private String discontinued;
    private String company;
    private boolean valid;

    @Qualifier
    public String getQualifier() {
        return name != null ? name : "Invalid entry";
    }

    @Test
    public void add_computer_should_validate_correctly() {
        user.is_on_home_page();
        user.navigates_to_add_computer_form();
        user.fills_computer_form(name, introduced, discontinued, company);
        user.submits_computer_form();

        if (valid) {
            user.should_see_success_message();
        } else {
            user.should_see_validation_errors();
        }
    }

    // Getters & Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getIntroduced() { return introduced; }
    public void setIntroduced(String introduced) { this.introduced = introduced; }

    public String getDiscontinued() { return discontinued; }
    public void setDiscontinued(String discontinued) { this.discontinued = discontinued; }

    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }

    // FIXED: Custom setter to parse "true"/"false" strings from CSV into boolean
    public boolean isValid() { return valid; }

    public void setValid(String valid) {
        this.valid = Boolean.parseBoolean(valid.trim());
    }
}
