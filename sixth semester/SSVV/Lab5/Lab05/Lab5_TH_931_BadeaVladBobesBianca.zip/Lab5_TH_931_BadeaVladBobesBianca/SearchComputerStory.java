package org.example.features.search;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.junit.annotations.UseTestDataFrom;
import net.thucydides.junit.annotations.Qualifier;
import org.example.steps.serenity.ComputerSteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/ComputerSearch.csv")
public class SearchComputerStory {

    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public ComputerSteps user;

    private String keyword;
    private String expected;
    private Boolean valid;  // ⬅️ IMPORTANT: Change from boolean to Boolean

    @Qualifier
    public String getQualifier() {
        return keyword;
    }

    @Test
    public void search_for_computer_should_return_expected_result() {
        user.is_on_home_page();
        user.searches_for_computer(keyword);

        if (Boolean.TRUE.equals(valid)) { // ⬅️ Safer check
            user.should_find_computer_matching(expected);
        } else {
            user.should_not_find_any_computer();
        }
    }

    // --- Getters and Setters ---

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getExpected() {
        return expected;
    }

    public void setExpected(String expected) {
        this.expected = expected;
    }

    public Boolean getValid() {
        return valid;
    }

    public void setValid(Boolean valid) {
        this.valid = valid;
    }
}
