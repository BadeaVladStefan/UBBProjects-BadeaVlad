package org.example.steps.serenity;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import org.example.pages.ComputerDatabasePage;

import java.util.List;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class ComputerSteps extends ScenarioSteps {

    ComputerDatabasePage computerPage;

    @Step
    public void is_on_home_page() {
        computerPage.open();
    }

    @Step
    public void searches_for_computer(String keyword) {
        System.out.println("DEBUG: Searching for -> " + keyword);
        computerPage.searchFor(keyword);
    }

    @Step
    public void should_find_computer_matching(String expected) {
        List<String> results = computerPage.getSearchResults();
        System.out.println("DEBUG: Search results -> " + results);

        boolean matchFound = results.stream()
                .anyMatch(result -> result.toLowerCase().contains(expected.toLowerCase()));

        assertThat("Expected to find a computer matching: " + expected, matchFound, is(true));
    }

    @Step
    public void should_not_find_any_computer() {
        List<String> results = computerPage.getSearchResults();
        System.out.println("DEBUG: Search results (should be empty) -> " + results);

        boolean noResults = results.isEmpty();
        assertThat("Expected no search results.", noResults, is(true));

        boolean noResultsMessageVisible = computerPage.isNoResultsMessageVisible();
        assertThat("Expected 'Nothing to display' message to be visible.", noResultsMessageVisible, is(true));
    }

    @Step
    public void navigates_to_add_computer_form() {
        computerPage.goToAddComputerForm();
    }

    @Step
    public void fills_computer_form(String name, String introduced, String discontinued, String company) {
        computerPage.fillComputerForm(name, introduced, discontinued, company);
    }

    @Step
    public void submits_computer_form() {
        computerPage.submitComputerForm();
    }

    @Step
    public void should_see_success_message() {
        // Small delay to avoid early check before message is rendered
        waitABit(1000);
        String message = computerPage.getSuccessMessage();
        System.out.println("DEBUG: Success message -> " + message);

        // Lowercase check for flexibility
        assertThat("Expected success message to contain 'has been created'.",
                message.toLowerCase(), containsString("has been created"));
    }

    @Step
    public void should_see_validation_errors() {
        boolean hasErrors = computerPage.hasValidationErrors();
        System.out.println("DEBUG: Validation errors -> " + hasErrors);
        assertThat("Expected validation errors to be shown.", hasErrors, is(true));
    }
}
