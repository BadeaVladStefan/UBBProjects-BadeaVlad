package org.example.features.search;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Issue;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Pending;
import net.thucydides.core.annotations.Steps;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import org.example.steps.serenity.EndUserSteps;

@RunWith(SerenityRunner.class)
public class SearchByKeywordStory {

    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public EndUserSteps anna;

    @Issue("#WIKI-1")
    @Test
    public void searching_by_keyword_apple_should_display_the_corresponding_article() {
        anna.is_the_home_page();
        anna.looks_for("apple");
        anna.should_see_definition("Rachel Appleby: Observations & Reflections: Learning from each other, learning from yourself");
    }

    @Test
    public void searching_by_keyword_training_should_display_the_corresponding_article() {
        anna.is_the_home_page();
        anna.looks_for("training");
        anna.should_see_definition("PLS Training pt Stiinte Reale\n" +
                "01.02.2024\n" +
                "Centrul Regional Nord-Vest de Orientare în Carieră al Cercetătorilor (UBB-CORE) este un proiect finanțat din fonduri europene și are ca scopuri principale furnizarea de servicii de orientare în cariera de cercetător de înaltă calitate și promovarea domeniului cercetării în rândul elevilor, studenților, doctoranzilor, cercetătorilor, cadrelor didactice, dar și în întreaga societate. Centrul UBB-CORE, organizează cursul\n" +
                "Vezi restul anunţului");
    }

    @Test
    public void searching_by_keyword_titlul_should_display_the_corresponding_article() {
        anna.is_the_home_page();
        anna.looks_for("titlul");
        anna.should_see_definition("Ceremonia de decernare a titlului de Profesor Honoris Causa domnului Dr. Ing. Oliver Oswald\n" +
                "29.09.2023\n" +
                "Universitatea Babeș-Bolyai vă invită să participați luni, 2 octombrie 2023, de la ora 17.00, la ceremonia de decernare a titlului de Profesor Honoris Causa domnului Dr. Ing. Oliver Oswald. Ceremonia de decernare a titlului Profesor Honoris Causa va fi organizată în Aula Magna a Universității Babeș-Bolyai (str. Mihail Kogălniceanu, nr. 1). Laudatio va fi prezentată\n" +
                "Vezi restul anunţului");
    }

    @Test
    public void searching_by_keyword_pear_should_display_the_corresponding_article() {
        anna.is_the_home_page();
        anna.looks_for("Lista");
        anna.should_see_definition("Lista participanților la Concursul MateInfo-UBB 2025 care beneficiază de facilități\n" +
                "17.04.2025\n" +
                "Vezi restul anunţului");
    }

    @Test
    public void searching_by_keyword_workshop_should_display_the_corresponding_article() {
        anna.is_the_home_page();
        anna.looks_for("workshop");
        anna.should_see_definition("workshop: Perioada: 25 – 27 aprilie Locația: str. Baritiu, nr. 26-28 (UTCN, Facultatea de Automatică și Calculatoare)");
    }

    @Pending
    @Test
    public void searching_by_ambiguous_keyword_should_display_the_disambiguation_page() {
        // This test is pending implementation
    }
}
