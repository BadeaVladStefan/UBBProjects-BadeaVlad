package model.stmt;

import model.ADT.MyIStack;
import model.ADT.MyStack;
import model.MyException;
import model.PrgState;

public class ForkStatement implements IStmt{
    private IStmt stmt;

    public ForkStatement(IStmt stmt) {
        this.stmt = stmt;
    }

    public IStmt getStmt() {
        return stmt;
    }

    @Override
    public String toString() {
        return "fork(" + stmt.toString() + ")";
    }

    @Override
    public PrgState execute(PrgState state) throws MyException {
        MyIStack<IStmt> newStack = new MyStack<IStmt>();
        return new PrgState(newStack,state.getSymTable().deepCopy(),state.getOut(),state.getFileTable(),stmt,state.getHeap());

    }
}
