from MainMenu.MainMenu import ConnectFourApp


if __name__ == '__main__':
    app = ConnectFourApp()
    app.mainloop()