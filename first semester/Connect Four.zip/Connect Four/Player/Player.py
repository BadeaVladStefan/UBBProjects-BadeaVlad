class Player:
    def __init__(self,color):
        self.color = color

    def make_move(self,board,column):
        pass